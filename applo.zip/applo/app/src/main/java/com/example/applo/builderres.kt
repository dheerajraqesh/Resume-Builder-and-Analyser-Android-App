package com.example.applo

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class builderres : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_builderres)

        val generateButton = findViewById<MaterialButton>(R.id.generateButton)
        generateButton.setOnClickListener {
            // Basic Information
            val name = findViewById<TextInputEditText>(R.id.nameInput).text.toString()
            val phone = findViewById<TextInputEditText>(R.id.phoneInput).text.toString()
            val email = findViewById<TextInputEditText>(R.id.emailInput).text.toString()

            // Social Links
            val linkedinUsername = findViewById<TextInputEditText>(R.id.linkedinUsernameInput).text.toString()
            val linkedinUrl = findViewById<TextInputEditText>(R.id.linkedinUrlInput).text.toString()
            val githubUrl = findViewById<TextInputEditText>(R.id.githubUrlInput).text.toString()
            val twitterUrl = findViewById<TextInputEditText>(R.id.twitterUrlInput).text.toString()

            // Address
            val district = findViewById<TextInputEditText>(R.id.districtInput).text.toString()
            val state = findViewById<TextInputEditText>(R.id.stateInput).text.toString()
            val pincode = findViewById<TextInputEditText>(R.id.pincodeInput).text.toString()
            val country = findViewById<TextInputEditText>(R.id.countryInput).text.toString()

            // Education
            val undergradCollege = findViewById<TextInputEditText>(R.id.undergradCollegeInput).text.toString()
            val undergradMajor = findViewById<TextInputEditText>(R.id.undergradMajorInput).text.toString()
            val undergradCgpa = findViewById<TextInputEditText>(R.id.undergradCgpaInput).text.toString()
            val undergradStartYear = findViewById<TextInputEditText>(R.id.undergradStartYearInput).text.toString()
            val undergradEndYear = findViewById<TextInputEditText>(R.id.undergradEndYearInput).text.toString()

            // Projects
            val projectDomain = findViewById<TextInputEditText>(R.id.projectDomainInput).text.toString()
            val projectTools = findViewById<TextInputEditText>(R.id.projectToolsInput).text.toString()
            val projectFeatures = findViewById<TextInputEditText>(R.id.projectFeaturesInput).text.toString()

            // Skills
            val programmingLanguages = findViewById<TextInputEditText>(R.id.programmingLanguagesInput).text.toString()
            val webTech = findViewById<TextInputEditText>(R.id.webTechInput).text.toString()
            val databases = findViewById<TextInputEditText>(R.id.databasesInput).text.toString()
            val otherTools = findViewById<TextInputEditText>(R.id.otherToolsInput).text.toString()

            // Work Experience
            val companyName = findViewById<TextInputEditText>(R.id.companyNameInput).text.toString()
            val position = findViewById<TextInputEditText>(R.id.positionInput).text.toString()
            val workExperienceDetails = findViewById<TextInputEditText>(R.id.workExperienceDetailsInput).text.toString()

            // Achievements
            val achievementDomain = findViewById<TextInputEditText>(R.id.achievementDomainInput).text.toString()
            val achievementLink=findViewById<TextInputEditText>(R.id.achievementLinkInput)
            // Validate required fields
            if (name.isEmpty() || phone.isEmpty() || email.isEmpty() ||
                district.isEmpty() || state.isEmpty() || pincode.isEmpty() || country.isEmpty() ||
                undergradCollege.isEmpty() || undergradMajor.isEmpty() || undergradCgpa.isEmpty() ||
                programmingLanguages.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // TODO: Add resume generation logic here
            Toast.makeText(this, "Generating resume...", Toast.LENGTH_SHORT).show()
        }
    }
}