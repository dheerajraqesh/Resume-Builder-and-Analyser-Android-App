package com.example.applo

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class Chhoice : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chhoice)

        val templateButton = findViewById<MaterialButton>(R.id.templateButton)
        val analyzeButton = findViewById<MaterialButton>(R.id.analyzeButton)

        templateButton.setOnClickListener {
            val intent = Intent(this, builderres::class.java)
            intent.putExtra("mode", "template")
            startActivity(intent)
        }
        analyzeButton.setOnClickListener {
            // Add resume analysis logic here
            Toast.makeText(this, "Analyzing resume...", Toast.LENGTH_SHORT).show()
        }
    }
}